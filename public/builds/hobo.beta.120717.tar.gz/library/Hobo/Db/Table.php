<?php

abstract class Hobo_Db_Table extends Zend_Db_Table {
    protected $_primary = 'id';
}
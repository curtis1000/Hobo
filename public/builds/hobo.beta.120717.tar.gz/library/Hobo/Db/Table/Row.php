<?php

abstract class Hobo_Db_Table_Row extends Zend_Db_Table_Row
{
    
}